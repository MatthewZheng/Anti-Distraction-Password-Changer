Click LifeScript.launch to open the app.

Cheers!
--Matthew